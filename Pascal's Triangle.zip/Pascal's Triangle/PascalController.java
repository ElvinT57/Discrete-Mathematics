import javafx.fxml.FXML;
import javafx.scene.layout.VBox;
import javafx.scene.control.TextField;
import java.util.ArrayList;
import javafx.scene.control.CheckBox;
public class PascalController {

    @FXML
    private VBox pane;

    @FXML
    private TextField rowField;
    @FXML
    private CheckBox shadedCheckBox;

    private ArrayList<Row> rows;
    private Runtime runtime = Runtime.getRuntime();
    @FXML
    void initialize() {
        assert pane != null : "fx:id=\"scrollpane\" was not injected: check your FXML file 'pascalMain.fxml'.";
        assert rowField != null : "fx:id=\"rowField\" was not injected: check your FXML file 'pascalMain.fxml'.";
        rows = new ArrayList<>();
    }

    public void calculate(){
        //reintialize the fields and create local variables
        boolean shaded = ((shadedCheckBox.isSelected() == true) ? true : false);
        rows = null; rows = new ArrayList<>();//reintialize the rows object to save memory
        //retrieve the amount of rows entered by the user
        int n = Integer.parseInt(rowField.getText());
        //clear out the pane
        pane.getChildren().clear();
        //add the top of the triangle 
        rows.add(new Row(shaded));
        pane.getChildren().add(rows.get(0));
        //calculate the other rows that were requested
        for(int i = 1; i< n; i++){
            rows.add(new Row(rows.get(i-1).getLength()+1, rows.get(i-1), shaded));
            pane.getChildren().add(rows.get(i));
            System.out.println("Max Memory: " + runtime.maxMemory());
            System.out.println("Free Memory: " + runtime.freeMemory());
            //System.gc();
        }

    }
}