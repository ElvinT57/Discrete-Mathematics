import javafx.scene.control.Label;
import javafx.scene.layout.HBox;
import javafx.geometry.Insets;
public class Row extends HBox
{
    private Label [] items;
    private boolean shaded;
    public Row(int numOfItems, Row previousRow, boolean shaded){
        items = new Label[numOfItems];
        this.shaded = shaded;
        calculateRow(previousRow);
    }

    public Row(boolean shaded){
        items = new Label[1];
        items[0] = new Label("1");
        this.getChildren().add(items[0]);
        this.shaded = shaded;
        style();
    }

    public void calculateRow(Row previousRow){
        int newLen = previousRow.getLength()+1;
        for(int i = 0; i < newLen; i++){
            if(i == 0 || i == newLen-1){
                items[i] = new Label("1");
                this.getChildren().add(items[i]);
            }
            else{
                String value = String.format("%.0f",previousRow.getItemAt(i-1) + previousRow.getItemAt(i)).replace(".0",""); 
                items[i] = new Label(value);
                this.getChildren().add(items[i]);
            }
        }
        style();    //style the items
    }

    public int getLength(){
        return items.length;   
    }

    public double getItemAt(int index){
        return Double.parseDouble(items[index].getText());
    }

    public String toString(){
        String str = "";
        for(int i = 0; i < getLength()-1; i++){
            str += items[i].getText() + " - ";
        }
        return str;
    }

    public void style(){
        //for the labels
        for(int i = 0; i < getLength(); i++){
            if(Double.parseDouble(items[i].getText()) % 2 != 0 && shaded ){
                items[i].setStyle("-fx-border-color: black;" 
                    + "-fx-font-size: 20px; -fx-background-color: #28A4FF; -fx-alignment: center;");
            }
            else{
                items[i].setStyle("-fx-border-color: black;" 
                    + "-fx-font-size: 20px; -fx-alignment: center;");
            }
            //set the margins of the labels and the also the preset size
            this.setMargin(items[i], new Insets(2,2,2,2));
            items[i].setPrefWidth(40); items[i].setPrefHeight(25);
            //also set the action listeners
            items[i].setOnMouseClicked(e -> {
                    Label lb = (Label)e.getSource();
                    AlertBox.display("Value", lb.getText());
                });
        }
        //alignment of the HBOX
        this.setStyle("-fx-alignment: center; ");
    }
}
