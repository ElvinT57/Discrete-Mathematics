import javafx.fxml.FXML;
import javafx.scene.control.TextField;

public class controller
{
    @FXML
    private TextField quotient;

    @FXML
    private TextField divisor;

    @FXML
    private TextField dividend;

    @FXML
    private TextField remainder;

    public void intiliaze(){
    }

    public void Calculate(){
        double q, dv, dd, r = 0;
        if(quotient.getText().equals("") && remainder.getText().equals("") && !dividend.getText().equals("") && !divisor.getText().equals("")){         
            //retrieve data
            dd = Double.parseDouble(dividend.getText());
            dv = Double.parseDouble(divisor.getText());
            r = 0;
            q = 0;
            
            //calculate
            q = Math.floor((dv/dd));
            r = dv - (dd * q );
            
            //sets the missing variables
            remainder.setText(Double.toString(r));
            quotient.setText(Double.toString(q));
        }
        else if(!quotient.getText().equals("") && remainder.getText().equals("") && !dividend.getText().equals("") && !divisor.getText().equals("")){
            //retrieve data
            dd = Double.parseDouble(dividend.getText());
            dv = Double.parseDouble(divisor.getText());
            r = 0;
            q = Double.parseDouble(quotient.getText());
            
            //calculate
            r = dv - (dd*q);
            
            //sets the missing variables
            remainder.setText(Double.toString(r));
        }
        else if(!quotient.getText().equals("") && !remainder.getText().equals("") && dividend.getText().equals("") && !divisor.getText().equals("")){
            dd = 0;
            dv = Double.parseDouble(divisor.getText());
            r = Double.parseDouble(remainder.getText());
            q = Double.parseDouble(quotient.getText());
            
            //calculate
            dv = dv - r;
            dd = dv / q;
            
            dividend.setText(Double.toString(dd));
        }
        else if(quotient.getText().equals("") && !remainder.getText().equals("") && !dividend.getText().equals("") && !divisor.getText().equals("")){
            dd = Double.parseDouble(dividend.getText());
            dv = Double.parseDouble(divisor.getText());
            r = Double.parseDouble(remainder.getText());
            q = 0;
            
            //calculate
            dv = dv - r;
            q = dv / dd;
            
            quotient.setText(Double.toString(q));
        }
        else if(!quotient.getText().equals("") && !remainder.getText().equals("") && !dividend.getText().equals("") && divisor.getText().equals("")){
            dd = Double.parseDouble(dividend.getText());
            dv = 0;
            r = Double.parseDouble(remainder.getText());
            q = Double.parseDouble(quotient.getText());
            
            dv = (dd * q) + r;
            divisor.setText(Double.toString(dv));
        }
        else if(quotient.getText().equals("") && !remainder.getText().equals("") && !dividend.getText().equals("") && divisor.getText().equals("")){
            dd = Double.parseDouble(dividend.getText());
            dv = 0;
            r = Double.parseDouble(remainder.getText());
            q = 0;
            int counter = 0;
            for(int i = 0; i < 1000; i++){  //let i = quotient
                    if(i % dd == r){
                        dv = i;
                        q = (dv- r)/dd;
                        System.out.println("===================================");
                        System.out.println("Possible Divisor: " + dv + "\nPossible Quotient: " + q);
                        counter++;
                    }
            }
            System.out.println("NUMBER OF POSSIBILITIES FOUND: " + counter);
        }
    }
}
