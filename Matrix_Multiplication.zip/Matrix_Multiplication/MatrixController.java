
import javafx.fxml.FXML;
import javafx.scene.control.Button;
import javafx.scene.layout.HBox;
import javafx.scene.image.ImageView;
public class MatrixController {

    
    @FXML
    private HBox pane1;

    @FXML
    private HBox pane2;

    @FXML
    private Button calculate;

    //Instance Variables
    Matrix matrix1;
    Matrix matrix2;
    Matrix result;
    public void initialize(){
        ///initialize all the matricies
        matrix1 = new Matrix();
        matrix2 = new Matrix();
        result = new Matrix();
        //add the two matricies to the panes
        pane1.getChildren().add(matrix1);
        pane2.getChildren().add(matrix2);
    }

    public void calculate(){
        //updates the values of the two matricies by using the input in the textfields
        matrix1.updateArray();
        matrix2.updateArray();
        //calculates the values of the result matrix
        for (int aRow= 0; aRow < matrix1.getN(); aRow++) { 
            for (int bCol = 0; bCol < matrix1.getN(); bCol++) { 
                for (int aCol = 0; aCol < matrix1.getN(); aCol++) { 
                    result.setElement(bCol,aRow, result.getElement(bCol,aRow)+(matrix1.getElement(aCol,aRow) * matrix2.getElement(bCol,aCol)));
                }
            }
        }
        //updates the result matrix's textfield
        result.updateArray();
        //displays the result matrix
        MatrixDisplayer.display(result);
        //resets the result to prevent accumalation
        result = new Matrix();
    }
}