
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.DatePicker;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;
import javafx.scene.layout.FlowPane;
import javafx.scene.layout.VBox;
import javafx.stage.Modality;
import javafx.stage.Stage;

/**
 * static class used to display a message on the screen using
 * the display static method.
 * 
 * @author Elvin Torres
 * @version 1.0
 */
public class MatrixDisplayer
{
    //Answer types
    public static final int NO_OPTION = 0;
    public static final int YES_OPTION = 1;
    //for the displayQuestion method
    private static int option = -1;
    /**
     * Displays a message in a new window
     * @param title Title of the window
     * @param message Message to display
     */
    public static void display(Matrix matrix){
        Stage window = new Stage();
        //sets the icon for the window(stage)
        //prevents user events in other windows/stages
        window.initModality(Modality.APPLICATION_MODAL);
        //sets the size of the window/stage
        window.setWidth(550);
        window.setHeight(600);
        window.setResizable(false);
        //sets the title of the window
        window.setTitle("Matrix Result");
        //----------Layout---------
        VBox box = new VBox();
        box.getChildren().addAll(matrix);
        //sets the alignment and other settings for the layout
        box.setAlignment(Pos.CENTER);
        box.setSpacing(10);
        //creates the scene of the window
        Scene scene = new Scene(box);
        //Sets the scene of the stage
        window.setScene(scene);
        //waits for the user to handle the window
        window.showAndWait(); 
    }//end display method

    }