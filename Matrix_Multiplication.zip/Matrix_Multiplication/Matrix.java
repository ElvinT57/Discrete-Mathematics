import javafx.scene.layout.*;
import javafx.scene.control.*;
import javafx.scene.text.*;
public class Matrix extends GridPane
{
    private int n = 3;
    private double [][] array2D;
    private TextField [][] label2D;
    private boolean empty; //var for checking if the matrix is empty
    public Matrix(){
        //calls super
        super();
        //setting the size for the grid
        this.setMaxHeight(500);
        this.setMaxWidth(500);
        //creates the rows and columns
        for(int i = 0; i< n; i++){
            RowConstraints row = new RowConstraints(170);
            this.getRowConstraints().add(row);
        }

        for(int i = 0; i< n; i++){
            ColumnConstraints col = new ColumnConstraints(170);
            this.getColumnConstraints().add(col);
        }
        //initializing the 2D array of values
        array2D = new double[n][n];
        //initializing the 2D array of label
        label2D = new TextField[n][n];
        for(int i = 0; i<n; i++){
            for(int j = 0; j<n; j++){
                array2D[i][j] = 0.0;
                //for textfield
                label2D[i][j] = new TextField("0");
                label2D[i][j].setPrefHeight(170);
                label2D[i][j].setPrefWidth(170);
                label2D[i][j].setFont(Font.font("Verdana", FontWeight.NORMAL, 50));

                this.add(label2D[i][j], i, j);
            }
        }
        empty = true;
    }

    public double getElement(int col, int row){
        return array2D[col][row];
    }

    public void setElement(int col, int row, double e){
        array2D[col][row] = e;
        empty = false;
    }

    public void updateArray(){
        if(empty){
            for(int i = 0; i<n; i++){
                for(int j = 0; j<n; j++){
                    array2D[i][j] = Double.parseDouble(label2D[i][j].getText());
                }
            }
        }
        else{
            for(int i = 0; i<n; i++){
                for(int j = 0; j<n; j++){
                    label2D[i][j].setText(Integer.toString((int)array2D[i][j]));
                }

            }
        }
    }

    public String toString(){
        return array2D.toString();   
    }

    public int getN(){
        return n;   
    }
}
