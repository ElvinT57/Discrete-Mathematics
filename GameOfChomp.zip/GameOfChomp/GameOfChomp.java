import javafx.application.*;
import javafx.fxml.FXMLLoader;
import javafx.scene.*;
import javafx.stage.*;
import javafx.fxml.FXML;
import java.io.IOException;
import javafx.scene.image.Image;
/**
 * Write a description of class BlackJack here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class GameOfChomp extends Application
{
    public void start(Stage stage) throws IOException{
        //load the FXML file.
        Parent parent = FXMLLoader.load(getClass().getResource("main.fxml"));
        //Build the scene graph
        Scene scene = new Scene(parent); 
        //display our window using the scene graph
        stage.setScene(scene);
        stage.setResizable(false);
        stage.setTitle("Game of Chomp");
        stage.setOnCloseRequest(e->{
                System.exit(0);
            });

        stage.show();
    }

    public static void main(String[] args){
        launch(args);
        
    }
}