import javafx.scene.image.ImageView;
import javafx.scene.image.Image;
/**
 * Cookie for the game of chomp. This class extends the imageview class from
 * JavaFX to inherit its image properties
 *
 * @author Elvin Torres
 * @version 1/18/18
 */
public class Cookie extends ImageView
{
    private int x, y;
    private boolean removed;
    
    public Cookie(int x, int y, boolean poisioned){
        super(); //call super's constructor   
        if(poisioned == false){  //hypothesis  
            //conclusion
            setImage(new Image("images//cookie.png"));  //good cookie
        }
        else{ 
            //poisioned cookie
            setImage(new Image("images//poisonedCookie.png"));
        }
        //intializes the row and col
        this.x = x;
        this.y = y;
        removed = false;
        //sets the size for the cookie
        setFitHeight(120);
        setFitWidth(120);
    }

    /**
     * Returns the x location of the cookie
     */
    public int getXLocation(){
        return x;   
    }

    /**
     * Returns the y location of the cookie
     */
    public int getYLocation(){
        return y;   
    }
    
    public void remove(){
      removed = true;  
    }
    
    public boolean hasBeenRemoved(){
        return removed;
    }
}
