import javafx.event.ActionEvent;
import javafx.scene.layout.GridPane;
import javafx.fxml.FXML;
import javafx.scene.control.Label;
/**
 * Write a description of class Controller here.
 *
 * @author (your name)
 * @version (a version number or a date)
 */
public class Controller
{
    @FXML
    private GridPane grid;
    @FXML
    private Label messageLabel;

    //fields for the game of chomp
    private boolean playerOnesTurn, playerTwosTurn;
    private int cookiesRemaining;
    private Cookie[][] cookies;
    private static int numOfCols = 4;
    private static int numOfRows = 4;
    public void initialize(){
        //start the game with player 1's turn
        playerOnesTurn = true;
        playerTwosTurn = false;

        cookiesRemaining = numOfCols*numOfRows;

        //intializing the cookies
        cookies = new Cookie[numOfCols][numOfRows];  //dimension of 4x4 cookies

        for(int x = 0; x<numOfCols; x++){
            for(int y = 0; y<numOfRows;  y++){
                if(x == 0 && y == numOfRows-1){       //IF it is the cookie on the lower left corner THEN make it posioned
                    cookies[x][y] = new Cookie(x,y,true);
                    grid.add(cookies[x][y],x,y);
                }
                else{           // ELSE create a normal cookie
                    cookies[x][y] = new Cookie(x,y, false);
                    grid.add(cookies[x][y],x,y);
                    //action listener
                    cookies[x][y].setOnMouseClicked(e ->{
                            Cookie cookie = (Cookie)e.getSource();
                            cookieClicked(cookie.getXLocation(), cookie.getYLocation());
                        });
                }
            }
        }
    }

    /**
     * When the cookie gets clicked, this method will be executed. 
     * This method will remove the clicked cookie and all the 
     * other cookies to the right and top of the clicked cookie.
     * 
     * After the cookies have been removed, the turns will be flipped 
     * and the game will continue until the last piece remains.
     * 
     */
    private void cookieClicked(int x, int y){
        for(int i = x; i<numOfCols; i++){
            for(int j = y; j>= 0; j--){
                removeCookieAt(i,j);
            }
        }

        //changes turns 
        negateTurns();
        if(playerOnesTurn){         // P -> Q
            displayMessage("Player One's Turn");
        }
        else{                           // (NOT)P -> (NOT)Q
            displayMessage("Player Two's Turn");
        }
        //checks if anyone has to eat the last cookie
        if( cookiesRemaining == 1 && playerOnesTurn == true){   // P^Q -> R
            displayMessage("Player One Lost!"); 
        }
        if( cookiesRemaining == 1 && playerTwosTurn == true){   // P^(NOT)Q -> R
            displayMessage("Player Two Lost!");
        }
    }

  
    private void removeCookieAt(int x, int y){
        if(!cookies[x][y].hasBeenRemoved()){    //if the cookie has NOT been removed
            grid.getChildren().remove(cookies[x][y]);   //remove from grid
            cookiesRemaining--; //subtract from the cookie count
            cookies[x][y].remove(); //set the boolean to true
        }
    }

    public void restartGame(){
        initialize();
    }

    public void negateTurns(){
        playerOnesTurn = !playerOnesTurn;
        playerTwosTurn = !playerTwosTurn;
    }

    public void displayMessage(String message){
        messageLabel.setText(message);   
    }
}